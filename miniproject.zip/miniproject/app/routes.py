from app import app

from flask import render_template
from flask_wtf import Form
from wtforms import StringField
from wtforms.validators import InputRequired
from .pillow import testa
import uuid

class MemeForm(Form):
    text1 = StringField('Text 1', validators=[InputRequired()])
    text2 = StringField('Text 2', validators=[InputRequired()])



@app.route('/', methods=['GET', 'POST'])
def index():
    form = MemeForm()
    if form.validate_on_submit():
        sample_out = uuid.uuid4()
        sample_out_html = 'pictures/sample_out/' + str(sample_out) + '.jpg'
        # form.title.data
        testa(250, 0, 250, 240, str(sample_out), '1', form.text1.data, form.text2.data)

        return render_template('meme.html', sample = sample_out_html)
    return render_template('index.html', form=form)
