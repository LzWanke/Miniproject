from app import app
from PIL import Image, ImageDraw, ImageFont
import os
# get an image

basedir = os.path.abspath(os.path.dirname(__file__))
app.logger.debug('basedir: %s', basedir)


def testa(width_t1, height_t1, width_t2, height_t2, sample_out, sample_in, text1, text2):
    infile = os.path.join(basedir, 'static/pictures/sample_in/' + sample_in + '.jpg')
    outfile = os.path.join(basedir, 'static/pictures/sample_out/' + sample_out + '.jpg')
    fontfile = os.path.join(basedir, 'font/Raleway-Regular.ttf')
#    size = 100, 2000
    base = Image.open(infile).convert('RGBA')
    #base.resize(size)


    fnt_size = (20)
    # make a blank image for the text, initialized to transparent text color
    txt = Image.new('RGBA', base.size, (255,255,255,0))

    # get a font
    fnt = ImageFont.truetype(fontfile, 100)
    # get a drawing context
    d = ImageDraw.Draw(txt)

    # draw text, half opacity
    d.text((width_t1, height_t1), text1, font=fnt, fill=(0,0,0,255))
    # draw text, full opacity
    d.text((width_t2, height_t2), text2, font=fnt, fill=(0,0,0,255))

    out = Image.alpha_composite(base, txt).convert('RGB')

    out.save(outfile)
